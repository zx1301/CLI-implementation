/** Anthony Kim
  CSC345-02
  lab2 ex 3 */
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <wait.h>

int main(int agc, char** argv){
	pid_t pid;
	pid = fork();
	if(pid ==0){
		//child process should finish asap
	}
	else if(pid > 0){
		sleep(30); //goes into waiting state, timer device interrupts cpu after 30 seconds
	}
	return 0;
}
